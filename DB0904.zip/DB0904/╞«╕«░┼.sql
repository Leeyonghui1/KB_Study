create or replace trigger trig_room
after insert on treatchart
declare memo treatchart%rowtype;
begin 
    select time, doc_id, nur_id, pat_id, diagnosis, prescription into memo.time, memo.doc_id, memo.nur_id, memo.pat_id, memo.diagnosis, memo.prescription from treatchart
    where prescription like '�Կ�'; 
    insert into room values(memo.time, memo.doc_id, memo.nur_id, memo.pat_id, memo.diagnosis, memo.prescription||'�� �Դϴ�');
 end;
 
