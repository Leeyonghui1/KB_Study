﻿namespace CSharp_teamProject
{
    partial class Login_up
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Login_up));
            this.Login_button4 = new System.Windows.Forms.Button();
            this.Login_button3 = new System.Windows.Forms.Button();
            this.Login_button2 = new System.Windows.Forms.Button();
            this.Login_button1 = new System.Windows.Forms.Button();
            this.Login_button5 = new System.Windows.Forms.Button();
            this.Login_pictureBox = new System.Windows.Forms.PictureBox();
            this.Login_button_Login = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.maskedTextBox1 = new System.Windows.Forms.MaskedTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Login_panel = new System.Windows.Forms.Panel();
            this.maskedTextBox2 = new System.Windows.Forms.MaskedTextBox();
            ((System.ComponentModel.ISupportInitialize)(this.Login_pictureBox)).BeginInit();
            this.Login_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // Login_button4
            // 
            this.Login_button4.BackColor = System.Drawing.Color.White;
            this.Login_button4.FlatAppearance.BorderSize = 0;
            this.Login_button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button4.Image = ((System.Drawing.Image)(resources.GetObject("Login_button4.Image")));
            this.Login_button4.Location = new System.Drawing.Point(317, 10);
            this.Login_button4.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button4.Name = "Login_button4";
            this.Login_button4.Size = new System.Drawing.Size(21, 18);
            this.Login_button4.TabIndex = 6;
            this.Login_button4.UseVisualStyleBackColor = false;
            // 
            // Login_button3
            // 
            this.Login_button3.BackColor = System.Drawing.Color.White;
            this.Login_button3.FlatAppearance.BorderSize = 0;
            this.Login_button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button3.Image = ((System.Drawing.Image)(resources.GetObject("Login_button3.Image")));
            this.Login_button3.Location = new System.Drawing.Point(234, 10);
            this.Login_button3.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button3.Name = "Login_button3";
            this.Login_button3.Size = new System.Drawing.Size(21, 19);
            this.Login_button3.TabIndex = 7;
            this.Login_button3.UseVisualStyleBackColor = false;
            // 
            // Login_button2
            // 
            this.Login_button2.BackColor = System.Drawing.Color.White;
            this.Login_button2.FlatAppearance.BorderSize = 0;
            this.Login_button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button2.Image = ((System.Drawing.Image)(resources.GetObject("Login_button2.Image")));
            this.Login_button2.Location = new System.Drawing.Point(191, 10);
            this.Login_button2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button2.Name = "Login_button2";
            this.Login_button2.Size = new System.Drawing.Size(21, 19);
            this.Login_button2.TabIndex = 8;
            this.Login_button2.UseVisualStyleBackColor = false;
            // 
            // Login_button1
            // 
            this.Login_button1.BackColor = System.Drawing.Color.White;
            this.Login_button1.FlatAppearance.BorderSize = 0;
            this.Login_button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button1.Image = ((System.Drawing.Image)(resources.GetObject("Login_button1.Image")));
            this.Login_button1.Location = new System.Drawing.Point(10, 10);
            this.Login_button1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button1.Name = "Login_button1";
            this.Login_button1.Size = new System.Drawing.Size(21, 19);
            this.Login_button1.TabIndex = 9;
            this.Login_button1.UseVisualStyleBackColor = false;
            this.Login_button1.Click += new System.EventHandler(this.Login_button1_Click);
            // 
            // Login_button5
            // 
            this.Login_button5.BackColor = System.Drawing.Color.White;
            this.Login_button5.FlatAppearance.BorderSize = 0;
            this.Login_button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button5.Image = ((System.Drawing.Image)(resources.GetObject("Login_button5.Image")));
            this.Login_button5.Location = new System.Drawing.Point(275, 10);
            this.Login_button5.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button5.Name = "Login_button5";
            this.Login_button5.Size = new System.Drawing.Size(21, 19);
            this.Login_button5.TabIndex = 10;
            this.Login_button5.UseVisualStyleBackColor = false;
            // 
            // Login_pictureBox
            // 
            this.Login_pictureBox.Dock = System.Windows.Forms.DockStyle.Right;
            this.Login_pictureBox.Image = ((System.Drawing.Image)(resources.GetObject("Login_pictureBox.Image")));
            this.Login_pictureBox.Location = new System.Drawing.Point(348, 0);
            this.Login_pictureBox.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_pictureBox.Name = "Login_pictureBox";
            this.Login_pictureBox.Size = new System.Drawing.Size(352, 360);
            this.Login_pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.Login_pictureBox.TabIndex = 5;
            this.Login_pictureBox.TabStop = false;
            // 
            // Login_button_Login
            // 
            this.Login_button_Login.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Login_button_Login.FlatAppearance.BorderSize = 0;
            this.Login_button_Login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Login_button_Login.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Login_button_Login.Location = new System.Drawing.Point(205, 253);
            this.Login_button_Login.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_button_Login.Name = "Login_button_Login";
            this.Login_button_Login.Size = new System.Drawing.Size(123, 50);
            this.Login_button_Login.TabIndex = 19;
            this.Login_button_Login.Text = "Login";
            this.Login_button_Login.UseVisualStyleBackColor = false;
            this.Login_button_Login.Click += new System.EventHandler(this.Login_button_Login_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.White;
            this.label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaption;
            this.label5.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label5.Location = new System.Drawing.Point(256, 322);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 19);
            this.label5.TabIndex = 11;
            this.label5.Text = "Sign up";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.White;
            this.label4.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label4.Location = new System.Drawing.Point(10, 329);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(140, 12);
            this.label4.TabIndex = 12;
            this.label4.Text = "Don\'t Have an Account?";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.White;
            this.label3.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label3.Location = new System.Drawing.Point(24, 153);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 12);
            this.label3.TabIndex = 13;
            this.label3.Text = "Password : ";
            // 
            // maskedTextBox1
            // 
            this.maskedTextBox1.Location = new System.Drawing.Point(146, 123);
            this.maskedTextBox1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.maskedTextBox1.Name = "maskedTextBox1";
            this.maskedTextBox1.Size = new System.Drawing.Size(162, 21);
            this.maskedTextBox1.TabIndex = 17;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.White;
            this.label2.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.label2.Location = new System.Drawing.Point(24, 126);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(97, 12);
            this.label2.TabIndex = 14;
            this.label2.Text = "Legend Name : ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Century Gothic", 21.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(22, 63);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 36);
            this.label1.TabIndex = 15;
            this.label1.Text = "Login";
            // 
            // Login_panel
            // 
            this.Login_panel.BackColor = System.Drawing.Color.White;
            this.Login_panel.Controls.Add(this.Login_button1);
            this.Login_panel.Controls.Add(this.maskedTextBox2);
            this.Login_panel.Controls.Add(this.label4);
            this.Login_panel.Controls.Add(this.Login_button_Login);
            this.Login_panel.Controls.Add(this.label5);
            this.Login_panel.Controls.Add(this.label3);
            this.Login_panel.Controls.Add(this.Login_button2);
            this.Login_panel.Controls.Add(this.maskedTextBox1);
            this.Login_panel.Controls.Add(this.Login_button5);
            this.Login_panel.Controls.Add(this.label2);
            this.Login_panel.Controls.Add(this.Login_button3);
            this.Login_panel.Controls.Add(this.label1);
            this.Login_panel.Controls.Add(this.Login_button4);
            this.Login_panel.Location = new System.Drawing.Point(0, 0);
            this.Login_panel.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Login_panel.Name = "Login_panel";
            this.Login_panel.Size = new System.Drawing.Size(428, 360);
            this.Login_panel.TabIndex = 19;
            // 
            // maskedTextBox2
            // 
            this.maskedTextBox2.Location = new System.Drawing.Point(146, 150);
            this.maskedTextBox2.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.maskedTextBox2.Name = "maskedTextBox2";
            this.maskedTextBox2.PasswordChar = '*';
            this.maskedTextBox2.Size = new System.Drawing.Size(162, 21);
            this.maskedTextBox2.TabIndex = 18;
            // 
            // Login_up
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(700, 360);
            this.Controls.Add(this.Login_pictureBox);
            this.Controls.Add(this.Login_panel);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "Login_up";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Form1";
            //this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Login_up_FormClosing);
       
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Login_up_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.Login_pictureBox)).EndInit();
            this.Login_panel.ResumeLayout(false);
            this.Login_panel.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Login_button4;
        private System.Windows.Forms.Button Login_button3;
        private System.Windows.Forms.Button Login_button2;
        private System.Windows.Forms.Button Login_button1;
        private System.Windows.Forms.Button Login_button5;
        private System.Windows.Forms.PictureBox Login_pictureBox;
        private System.Windows.Forms.Button Login_button_Login;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.MaskedTextBox maskedTextBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel Login_panel;
        private System.Windows.Forms.MaskedTextBox maskedTextBox2;
    }
}