﻿namespace CSharp_teamProject
{
    partial class MyPage
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.MyPage_label8_2 = new System.Windows.Forms.Label();
            this.MyPage_label7_2 = new System.Windows.Forms.Label();
            this.MyPage_label6_2 = new System.Windows.Forms.Label();
            this.MyPage_label5_2 = new System.Windows.Forms.Label();
            this.MyPage_label4_2 = new System.Windows.Forms.Label();
            this.MyPage_label3_2 = new System.Windows.Forms.Label();
            this.MyPage_label1_2 = new System.Windows.Forms.Label();
            this.MyPage_label2_2 = new System.Windows.Forms.Label();
            this.MyPage_button1 = new System.Windows.Forms.Button();
            this.MyPage_listBox1 = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // MyPage_label8_2
            // 
            this.MyPage_label8_2.AutoSize = true;
            this.MyPage_label8_2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MyPage_label8_2.Location = new System.Drawing.Point(172, 298);
            this.MyPage_label8_2.Name = "MyPage_label8_2";
            this.MyPage_label8_2.Size = new System.Drawing.Size(0, 27);
            this.MyPage_label8_2.TabIndex = 15;
            // 
            // MyPage_label7_2
            // 
            this.MyPage_label7_2.AutoSize = true;
            this.MyPage_label7_2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MyPage_label7_2.Location = new System.Drawing.Point(172, 220);
            this.MyPage_label7_2.Name = "MyPage_label7_2";
            this.MyPage_label7_2.Size = new System.Drawing.Size(0, 27);
            this.MyPage_label7_2.TabIndex = 14;
            // 
            // MyPage_label6_2
            // 
            this.MyPage_label6_2.AutoSize = true;
            this.MyPage_label6_2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MyPage_label6_2.Location = new System.Drawing.Point(172, 136);
            this.MyPage_label6_2.Name = "MyPage_label6_2";
            this.MyPage_label6_2.Size = new System.Drawing.Size(0, 27);
            this.MyPage_label6_2.TabIndex = 13;
            // 
            // MyPage_label5_2
            // 
            this.MyPage_label5_2.AutoSize = true;
            this.MyPage_label5_2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MyPage_label5_2.Location = new System.Drawing.Point(172, 42);
            this.MyPage_label5_2.Name = "MyPage_label5_2";
            this.MyPage_label5_2.Size = new System.Drawing.Size(0, 27);
            this.MyPage_label5_2.TabIndex = 12;
            // 
            // MyPage_label4_2
            // 
            this.MyPage_label4_2.AutoSize = true;
            this.MyPage_label4_2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MyPage_label4_2.Location = new System.Drawing.Point(24, 303);
            this.MyPage_label4_2.Name = "MyPage_label4_2";
            this.MyPage_label4_2.Size = new System.Drawing.Size(106, 27);
            this.MyPage_label4_2.TabIndex = 11;
            this.MyPage_label4_2.Text = "이메일 ";
            // 
            // MyPage_label3_2
            // 
            this.MyPage_label3_2.AutoSize = true;
            this.MyPage_label3_2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MyPage_label3_2.Location = new System.Drawing.Point(20, 218);
            this.MyPage_label3_2.Name = "MyPage_label3_2";
            this.MyPage_label3_2.Size = new System.Drawing.Size(134, 27);
            this.MyPage_label3_2.TabIndex = 10;
            this.MyPage_label3_2.Text = "휴대전화 ";
            // 
            // MyPage_label1_2
            // 
            this.MyPage_label1_2.AutoSize = true;
            this.MyPage_label1_2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MyPage_label1_2.Location = new System.Drawing.Point(24, 40);
            this.MyPage_label1_2.Name = "MyPage_label1_2";
            this.MyPage_label1_2.Size = new System.Drawing.Size(78, 27);
            this.MyPage_label1_2.TabIndex = 9;
            this.MyPage_label1_2.Text = "이름 ";
            // 
            // MyPage_label2_2
            // 
            this.MyPage_label2_2.AutoSize = true;
            this.MyPage_label2_2.Font = new System.Drawing.Font("굴림", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(129)));
            this.MyPage_label2_2.Location = new System.Drawing.Point(24, 134);
            this.MyPage_label2_2.Name = "MyPage_label2_2";
            this.MyPage_label2_2.Size = new System.Drawing.Size(106, 27);
            this.MyPage_label2_2.TabIndex = 8;
            this.MyPage_label2_2.Text = "아이디 ";
            // 
            // MyPage_button1
            // 
            this.MyPage_button1.Location = new System.Drawing.Point(29, 358);
            this.MyPage_button1.Name = "MyPage_button1";
            this.MyPage_button1.Size = new System.Drawing.Size(75, 23);
            this.MyPage_button1.TabIndex = 18;
            this.MyPage_button1.Text = "예약확인";
            this.MyPage_button1.UseVisualStyleBackColor = true;
            this.MyPage_button1.Click += new System.EventHandler(this.MyPage_button1_Click);
            // 
            // MyPage_listBox1
            // 
            this.MyPage_listBox1.FormattingEnabled = true;
            this.MyPage_listBox1.ItemHeight = 12;
            this.MyPage_listBox1.Location = new System.Drawing.Point(40, 394);
            this.MyPage_listBox1.Name = "MyPage_listBox1";
            this.MyPage_listBox1.Size = new System.Drawing.Size(721, 244);
            this.MyPage_listBox1.TabIndex = 19;
            // 
            // MyPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(914, 650);
            this.Controls.Add(this.MyPage_listBox1);
            this.Controls.Add(this.MyPage_button1);
            this.Controls.Add(this.MyPage_label8_2);
            this.Controls.Add(this.MyPage_label7_2);
            this.Controls.Add(this.MyPage_label6_2);
            this.Controls.Add(this.MyPage_label5_2);
            this.Controls.Add(this.MyPage_label4_2);
            this.Controls.Add(this.MyPage_label3_2);
            this.Controls.Add(this.MyPage_label1_2);
            this.Controls.Add(this.MyPage_label2_2);
            this.Name = "MyPage";
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
            this.Text = "MyPage";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label MyPage_label8_2;
        private System.Windows.Forms.Label MyPage_label7_2;
        private System.Windows.Forms.Label MyPage_label6_2;
        private System.Windows.Forms.Label MyPage_label5_2;
        private System.Windows.Forms.Label MyPage_label4_2;
        private System.Windows.Forms.Label MyPage_label3_2;
        private System.Windows.Forms.Label MyPage_label1_2;
        private System.Windows.Forms.Label MyPage_label2_2;
        private System.Windows.Forms.Button MyPage_button1;
        private System.Windows.Forms.ListBox MyPage_listBox1;
    }
}