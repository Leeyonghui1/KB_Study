﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CSharp_teamProject
{
    public partial class Form1 : Form
    {
        List<String> choice_list = new List<string>();
        private void ReadHotelList()
        {
            StreamReader file = new StreamReader("HotelList.csv", System.Text.Encoding.Default);
            DataTable table = new DataTable();
            string line1 = file.ReadLine();
            string[] data1 = line1.Split(',');

            table.Columns.Add(data1[1]); // 호텔명
            table.Columns.Add(data1[2]); // 전화번호
            table.Columns.Add(data1[3]); // 우편번호
            table.Columns.Add(data1[4]); // 도로명주소
            table.Columns.Add(data1[5]); // 객실수

            while(!file.EndOfStream)
            {
                string line = file.ReadLine();
                string[] data = line.Split(',');
                table.Rows.Add(data[1], data[2], data[3], data[4], data[5]);
            }
            dataGridView1.DataSource = table;
            file.Close();
        }
        
        private void Choice_Area(List<String> choice_text)
        {
            StreamReader file = new StreamReader("HotelList.csv", System.Text.Encoding.Default);
            DataTable table = new DataTable();
            string line1 = file.ReadLine();
            string[] data1 = line1.Split(',');

            table.Columns.Add(data1[1]);
            table.Columns.Add(data1[2]);
            table.Columns.Add(data1[3]);
            table.Columns.Add(data1[4]);
            table.Columns.Add(data1[5]);

            while (!file.EndOfStream)
            {
                string line = file.ReadLine();
                string[] data = line.Split(',');
                foreach (var item in choice_list)
                {
                    if (data[4].ToString().Contains(item))
                        table.Rows.Add(data[1], data[2], data[3], data[4], data[5]);
                }
            }
            dataGridView1.DataSource = table;
            file.Close();
        }

        private void Search_Area(string search_text)
        {
            StreamReader file = new StreamReader("HotelList.csv", System.Text.Encoding.Default);
            DataTable table = new DataTable();
            string line1 = file.ReadLine();
            string[] data1 = line1.Split(',');

            table.Columns.Add(data1[1]);
            table.Columns.Add(data1[2]);
            table.Columns.Add(data1[3]);
            table.Columns.Add(data1[4]);
            table.Columns.Add(data1[5]);

            while (!file.EndOfStream)
            {
                string line = file.ReadLine();
                string[] data = line.Split(',');
                if (data[1].ToString().Contains(search_text))
                    table.Rows.Add(data[1], data[2], data[3], data[4], data[5]);
            }
            dataGridView1.DataSource = table;
            file.Close();
        }

        private void CleanList()
        {
            dataGridView1.DataSource = null;
        }

        private void CleanChoiceList(string txt)
        {
            choice_list.Remove(txt);
        }
        
        public Form1()
        {
            InitializeComponent();
            ReadHotelList();
        }
        
        private void button1_Click(object sender, EventArgs e)
        {
            CleanList();
            Search_Area(textBox1.Text);
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            CleanList();
            if(checkBox1.Checked)
                choice_list.Add(checkBox1.Text);
            else
                CleanChoiceList(checkBox1.Text);

            Choice_Area(choice_list);
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            CleanList();
            if(checkBox2.Checked)
                choice_list.Add(checkBox2.Text);
            else
                CleanChoiceList(checkBox2.Text);
            Choice_Area(choice_list);
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            CleanList();
            if (checkBox3.Checked)
                choice_list.Add(checkBox3.Text);
            else
                CleanChoiceList(checkBox3.Text);
            Choice_Area(choice_list);
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            CleanList();
            if (checkBox4.Checked)
                choice_list.Add(checkBox4.Text);
            else
                CleanChoiceList(checkBox4.Text);
            Choice_Area(choice_list);
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            CleanList();
            if (checkBox5.Checked)
                choice_list.Add(checkBox5.Text);
            else
                CleanChoiceList(checkBox5.Text);
            Choice_Area(choice_list);
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            CleanList();
            if (checkBox6.Checked)
                choice_list.Add(checkBox6.Text);
            else
                CleanChoiceList(checkBox6.Text);
            Choice_Area(choice_list);
        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {
            CleanList();
            checkBox7.Text = "전라";
            if (checkBox7.Checked)
                choice_list.Add(checkBox7.Text);
            else
                CleanChoiceList(checkBox7.Text); 
            Choice_Area(choice_list);
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            CleanList();
            checkBox8.Text = "경상";
            if (checkBox8.Checked)
                choice_list.Add(checkBox8.Text);
            else
                CleanChoiceList(checkBox8.Text);
            Choice_Area(choice_list);
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            CleanList();
            checkBox9.Text = "충청";
            if (checkBox9.Checked)
                choice_list.Add(checkBox9.Text);
            else
                CleanChoiceList(checkBox9.Text);
            Choice_Area(choice_list);
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            StreamReader file = new StreamReader("HotelList.csv", System.Text.Encoding.Default);
        
            int rowIndex = dataGridView1.CurrentCell.RowIndex;
            string cellclick_text = dataGridView1.Rows[rowIndex].Cells[0].Value.ToString();

            while (!file.EndOfStream)
            {
                string line = file.ReadLine();
                string[] data = line.Split(',');
                if (data[1].ToString().Contains(cellclick_text))
                {
                    object[] pos = new object[] { data[7], data[6] };
                    HtmlDocument hdoc = webBrowser1.Document;
                    hdoc.InvokeScript("setCenter", pos);
                    break;
                }    
            }
            file.Close();
        }
    }
}
