﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolT2
{
    public class Pig : Animal
    {
        public override void eat()
        {
            System.Windows.Forms.MessageBox.Show("꿀꿀꿀");
        }
    }
}
