﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace T2
{
    public struct KBStudent
    {
        public string Name;
        public string MBTI;
        public int Age;
        public double Eye;
    }
}
