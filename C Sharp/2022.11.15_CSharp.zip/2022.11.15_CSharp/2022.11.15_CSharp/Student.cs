﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2022._11._15_CSharp
{
    public struct Student
    {
        public int Age;
        public string Name;
        public double eye;
    }
}
