﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P4
{
    public interface ICharming
    {
        void actCute();
        void wellCome();
        void smile();
    }
}
