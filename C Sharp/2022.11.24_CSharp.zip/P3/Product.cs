﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace P3
{
    public class Product
    {
        public int Id;  // DataGridView에서 나타나지 않음

        public string Name { get; set; }
        public int Price { get; set; }
    }
}
