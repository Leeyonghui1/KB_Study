#include<stdio.h>
#include"pr1.h"
#include"pr2.h"
#include"pr3.h"
#include"pr4.h"
#include"pr4_1.h"
#include"pr5.h"
#include"pr6.h"
#include"pr7.h"
#include"pr8.h"
#include"pr9.h"
#include"pr10.h"
int main()
{
	//int result = calcul(); p1
	
	//int trans = time(); pr2
	
	//ColorChange();   pr3
	
	/* pr4
	Colorkinds colorkinds;
	ColorSet(���, ���);
	*/
	// Color(0, 9);    pr4_1
	
	// Sum();  pr5
	
	// mul(1, 5); pr6
    
	// cal(1, 5, 'x');  pr7

	// pro1(5); pr8

	/*  pr9
	int result = pro2(5);
	printf("total = %d", result);
	*/
	
	/*  pr10
	int n;
	scanf_s("%d", &n);
	int result = pattern(n);
	printf("%d", result);
	*/
	
	return 0;

}