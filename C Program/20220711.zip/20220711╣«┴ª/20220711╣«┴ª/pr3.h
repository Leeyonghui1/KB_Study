#pragma once
#include<stdio.h>
#include<Windows.h>
void ColorChange()
{
	system("color a0");
}