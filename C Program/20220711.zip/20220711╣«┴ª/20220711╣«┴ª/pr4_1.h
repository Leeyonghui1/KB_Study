#pragma once
#include<stdio.h>

void Color(char a, char b)
{
	int 
}