insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2220110001,'01','�̿���','M',31,'010-1111-2222','101');
insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2220110002,'01','�̿���','M',28,'010-1112-2222','101');
insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2220110003,'01','�̿���','G',35,'010-1113-2222','103');
insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2220510001,'05','�̿���','M',48,'010-1114-2222','105');            
insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2220810001,'08','�̿���','G',31,'010-1115-2222','104');
insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2221210001,'12','�̿���','M',51,'010-1116-2222','106');
insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2221310001,'13','�̿���','G',37,'010-1117-2222','102');            
insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2220110004,'01','�̿���','M',31,'010-1124-2222','102');            
insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2221410001,'14','�̿���','M',41,'010-1118-2222','104');
insert into person(pt_code,doc_id,m_code,name,gen,age,phone,po_code)
            values('001',2224910001,'49','�̿���','G',39,'010-1119-2222','103');


insert into person(pt_code,nur_id,m_code,name,gen,age,phone,po_code)
            values('002',2220120001,'01','�̿���','G',28,'010-1212-2222','201');
insert into person(pt_code,nur_id,m_code,name,gen,age,phone,po_code)
            values('002',2220520001,'05','�̿���','M',33,'010-1111-2223','202');
insert into person(pt_code,nur_id,m_code,name,gen,age,phone,po_code)
            values('002',2220820001,'08','�̿���','G',28,'010-1111-2224','201');
insert into person(pt_code,nur_id,m_code,name,gen,age,phone,po_code)
            values('002',2221220001,'12','�̿���','G',38,'010-1111-2225','204');
insert into person(pt_code,nur_id,m_code,name,gen,age,phone,po_code)
            values('002',2221320001,'13','�̿���','G',35,'010-1111-2226','203');
insert into person(pt_code,nur_id,m_code,name,gen,age,phone,po_code)
            values('002',2221420001,'14','�̿���','G',31,'010-1111-2227','202');
insert into person(pt_code,nur_id,m_code,name,gen,age,phone,po_code)
            values('002',2224920001,'49','�̿���','M',30,'010-1111-2228','201');
insert into person(pt_code,nur_id,m_code,name,gen,age,phone,po_code)
            values('002',2220820002,'08','�̿���','G',26,'010-1111-2229','201');
insert into person(pt_code,nur_id,m_code,name,gen,age,phone,po_code)
            values('002',2220520002,'05','�̿���','G',27,'010-1111-2210','201');


insert into person(pt_code,pat_id,name,gen,age,phone)
            values('003',1,'�̿���','M',19,'010-3111-2222');
insert into person(pt_code,pat_id,name,gen,age,phone)
            values('003',2,'�̿���','M',30,'010-3111-2224');
insert into person(pt_code,pat_id,name,gen,age,phone)
            values('003',3,'�̿���','G',20,'010-3234-5678');            
insert into person(pt_code,pat_id,name,gen,age,phone)
            values('003',4,'�̿���','M',28,'010-4234-5678');
insert into person(pt_code,pat_id,name,gen,age,phone)
            values('003',5,'�̿���','G',47,'010-5234-5678');

select * from person;
commit;
update person set name='�����' where nur_id=2220120001;
insert into treatchart values(2209001,'22/09/02',2220110001,2220120001,1,'�����','�忰','�Կ�');
select id ��Ʈ��ȣ, time ����, person.name ����ǻ�, person.name ��簣ȣ��, per  from treatchart;
select * from treatchart;