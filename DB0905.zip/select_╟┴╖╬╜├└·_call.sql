var o_cursor refcursor 
exec select_person('�ְ�â��', :o_cursor)
print o_cursor;
