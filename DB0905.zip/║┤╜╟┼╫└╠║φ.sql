create table room
(
    time      date           not null,
    doc_id    number(10)     not null,
    nur_id    number(10)     not null,
    pat_id    number         not null,
    diagnosis varchar2(1000) not null
    );
    
select distinct * from room;
select * from room;
delete from room;
drop table room;