package test1;

public class Square {
	private int wh;

	// ������
	public Square() {
		
	}
	public Square(int wh) {
		this.wh = wh;
	}
	
	// �޼ҵ�
	public int getWh() {return wh;}
	public void setWh(int wh) {this.wh = wh;}
	
	

}
