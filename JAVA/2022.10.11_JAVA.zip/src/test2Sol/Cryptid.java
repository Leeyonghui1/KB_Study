package test2Sol;
// ȯ���� ������
public abstract class Cryptid extends Animal implements Fliable, Runable {

	@Override
	public void Run() {
		
	}

	@Override
	public void Jog() {
		// TODO Auto-generated method stub

	}

	@Override
	public void Fly() {
		// TODO Auto-generated method stub

	}

	@Override
	public void FlapWing() {
		// TODO Auto-generated method stub

	}

	@Override
	public void sleep() {
		// TODO Auto-generated method stub

	}

}
