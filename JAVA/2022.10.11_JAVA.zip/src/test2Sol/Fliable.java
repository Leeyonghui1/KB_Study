package test2Sol;

public interface Fliable {
	public void Fly();
	public void FlapWing();
}
