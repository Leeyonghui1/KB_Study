package test2Sol;

public interface Runable {
	public void Run();
	public void Jog();
}
