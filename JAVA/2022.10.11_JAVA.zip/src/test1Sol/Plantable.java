package test1Sol;

public interface Plantable {
	public void grow();
}
