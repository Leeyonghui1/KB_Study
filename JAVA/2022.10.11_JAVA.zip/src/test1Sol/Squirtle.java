package test1Sol;

public class Squirtle implements Pokemonable {

	@Override
	public void charming() {
		System.out.println("���ϲ���~");
	}

	@Override
	public void grow() {
		return; 
	}

	@Override
	public void fight() {
		System.out.println("������~");
	}

}
