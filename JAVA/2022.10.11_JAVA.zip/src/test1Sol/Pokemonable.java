package test1Sol;

public interface Pokemonable extends Animalable, Plantable{
	public void fight();
}
