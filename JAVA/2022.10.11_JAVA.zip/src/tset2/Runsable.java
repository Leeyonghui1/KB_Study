package tset2;

public interface Runsable {
	public void Run();
	public void Jog();
}
