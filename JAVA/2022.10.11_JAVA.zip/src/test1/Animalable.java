package test1;

public interface Animalable {
	public void charming();

}
