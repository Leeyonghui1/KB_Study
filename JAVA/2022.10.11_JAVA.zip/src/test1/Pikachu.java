package test1;

public class Pikachu implements Animalable{

	@Override
	public void charming() {
		// TODO Auto-generated method stub
		System.out.println("��ī��~~");
	}

}
