package test1;

public interface Pokemonable extends Animalable, Plantable {
	public void fight();
}
