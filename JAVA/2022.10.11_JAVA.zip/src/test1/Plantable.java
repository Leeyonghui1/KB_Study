package test1;

public interface Plantable {
	public void grow();
}
