package Factory01_SimpleFactory;

public abstract class Food {
    public abstract void prepared();
    public abstract void tryEat();
}
