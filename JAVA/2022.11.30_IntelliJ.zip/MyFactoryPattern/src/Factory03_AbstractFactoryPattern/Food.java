package Factory03_AbstractFactoryPattern;

public abstract class Food {
    public abstract void prepared();
    public abstract void tryEat();
}
