package Factory03_AbstractFactoryPattern;

public abstract class comprehensiveFactory {
    public abstract FoodFactory requestFood(String type);
}
