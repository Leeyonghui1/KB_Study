public abstract class Food {
    public abstract void prepared();
    public abstract void tryEat();
}
