package com.lec.ex;

public class InsertPrint implements ExecutePrintable {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		System.out.println("I N S E R T !");
	}

}
