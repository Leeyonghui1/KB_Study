package com.lec.ex;

public class TestPrint implements ExecutePrintable {

	@Override
	public void execute() {
		// TODO Auto-generated method stub
		System.out.println("T E S T !");
	}

}
