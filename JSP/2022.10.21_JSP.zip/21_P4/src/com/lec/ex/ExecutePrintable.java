package com.lec.ex;

public interface ExecutePrintable {
	public void execute();
}
