
insert into customer(custid,name) values('tempUser', '비회원');

select * from customer;