select * from customer order by insert_date desc;

select * from customerlog;


update customerlog set custLogTime=now() where custNum=1;

 
insert into customer(custid,name) values('cust001','이동준1');
insert into customer(custid,name) values('cust002','이동준2');
insert into customer(custid,name) values('cust003','이동준3');
insert into customer(custid,name) values('cust004','이동준4');
insert into customer(custid,name) values('cust005','이동준5'); 
insert into customer(custid,name) values('cust006','이동준6');
insert into customer(custid,name) values('cust007','이동준7');
insert into customer(custid,name) values('cust008','이동준8');
insert into customer(custid,name) values('cust009','이동준9');
insert into customer(custid,name) values('cust010','이동준10');



insert into customer(custid,name) values('cust011','최호준1');
insert into customer(custid,name) values('cust012','최호준2');
insert into customer(custid,name) values('cust013','최호준3');
insert into customer(custid,name) values('cust014','최호준4');
insert into customer(custid,name) values('cust015','최호준5'); 
insert into customer(custid,name) values('cust016','최호준6');
insert into customer(custid,name) values('cust017','최호준7');
insert into customer(custid,name) values('cust018','최호준8');
insert into customer(custid,name) values('cust019','최호준9');
insert into customer(custid,name) values('cust020','최호준10');


insert into customer(custid,name) values('cust021','이현민1');
insert into customer(custid,name) values('cust022','이현민2');
insert into customer(custid,name) values('cust023','이현민3');
insert into customer(custid,name) values('cust024','이현민4');
insert into customer(custid,name) values('cust025','이현민5'); 
insert into customer(custid,name) values('cust026','이현민6');
insert into customer(custid,name) values('cust027','이현민7');
insert into customer(custid,name) values('cust028','이현민8');
insert into customer(custid,name) values('cust029','이현민9');
insert into customer(custid,name) values('cust030','이현민10');



