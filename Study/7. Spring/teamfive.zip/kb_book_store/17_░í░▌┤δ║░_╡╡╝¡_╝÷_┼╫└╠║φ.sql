create table bookPrice 
(
rownum int primary key auto_increment,
priceRange varchar(100),
countPrice int
);