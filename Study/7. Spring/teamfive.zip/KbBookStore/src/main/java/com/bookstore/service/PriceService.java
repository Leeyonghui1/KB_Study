package com.bookstore.service;

import java.util.List;
import java.util.Map;

public interface PriceService {

	List<Map<String, Object>> list();
}
















