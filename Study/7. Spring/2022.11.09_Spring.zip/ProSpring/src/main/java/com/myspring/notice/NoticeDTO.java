package com.myspring.notice;

public class NoticeDTO {
	
	
	
}
