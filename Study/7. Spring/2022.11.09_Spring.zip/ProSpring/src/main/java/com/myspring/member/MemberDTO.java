package com.myspring.member;

public class MemberDTO {
	private String name;
	private String id;
	private String pw;
	private String gender;
	private String email;
	private String phone;
	private String birth;
	private String post;
	private String addr;
	private String pt_code;
	private String m_code;
	private String jpo_code;
	
	public MemberDTO() {
		
	}
	
	public MemberDTO(String name, String id, String pw, String gender, String email, String phone, String birth,
			String post, String addr, String pt_code, String m_code, String jpo_code) {
		this.name = name;
		this.id = id;
		this.pw = pw;
		this.gender = gender;
		this.email = email;
		this.phone = phone;
		this.birth = birth;
		this.post = post;
		this.addr = addr;
		this.pt_code = pt_code;
		this.m_code = m_code;
		this.jpo_code = jpo_code;
	}

	public String getName() {return name;}	
	public void setName(String name) {this.name = name;}
	public String getId() {return id;}
	public void setId(String id) {this.id = id;}
	public String getPw() {return pw;}
	public void setPw(String pw) {this.pw = pw;}
	public String getGender() {return gender;}
	public void setGender(String gender) {this.gender = gender;}
	public String getEmail() {return email;}
	public void setEmail(String email) {this.email = email;}
	public String getPhone() {return phone;}
	public void setPhone(String phone) {this.phone = phone;}
	public String getBirth() {return birth;}
	public void setBirth(String birth) {this.birth = birth;}
	public String getPost() {return post;}
	public void setPost(String post) {this.post = post;}
	public String getAddr() {return addr;}
	public void setAddr(String addr) {this.addr = addr;}
	public String getPt_code() {return pt_code;}
	public void setPt_code(String pt_code) {this.pt_code = pt_code;}
	public String getM_code() {return m_code;}
	public void setM_code(String m_code) {this.m_code = m_code;}
	public String getJpo_code() {return jpo_code;}
	public void setJpo_code(String jpo_code) {this.jpo_code = jpo_code;}
	
	
}
