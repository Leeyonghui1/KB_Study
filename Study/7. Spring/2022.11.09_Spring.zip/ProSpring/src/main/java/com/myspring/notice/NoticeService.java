package com.myspring.notice;

import java.util.List;



public interface NoticeService {

	List<NoticeDTO> notice_list();

}
