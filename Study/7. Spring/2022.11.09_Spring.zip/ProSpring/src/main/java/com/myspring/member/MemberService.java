package com.myspring.member;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface MemberService {

	List<MemberDTO> staff_list(String m_code);

	boolean id_check(String id);

	String join(Map<String, Object> map);

	MemberDTO login(HashMap<String, String> map);

	MemberDTO detail(String id);
	
	boolean delete(String id);

	boolean modify(Map<String, Object> map);

}
