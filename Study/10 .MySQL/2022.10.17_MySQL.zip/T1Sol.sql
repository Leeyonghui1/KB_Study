select * from employeesol;
-- 쿼리문이 아닌 GUI를 사용하여 데이터 추가함


-- 테이터베이스(스키마) 선택하는 것
-- 내가 작업하고자 하는 데이터베이스를 선택한 뒤 쿼리문 작성해야함
-- 스키마 더블클릭 or use 스키마명 실행
use sys;
use hellojavaweb;
