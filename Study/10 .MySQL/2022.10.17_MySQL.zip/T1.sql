create table Employee(
name varchar(100),
sabeon int primary key,
buseo varchar(100)
);

insert into Employee values('이용희',1,'인사과');
insert into Employee values('이용희',2,'총무과');
insert into Employee values('이용희',3,'기술팀');

select * from Employee;