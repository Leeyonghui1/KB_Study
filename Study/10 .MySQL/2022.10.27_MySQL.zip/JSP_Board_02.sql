create table sequences
(
	name varchar(32),
    currval bigint unsigned
);