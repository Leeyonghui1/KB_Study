package test2Sol;

public class MathTeacher extends Teacher {

	@Override
	public void Teach() {
		// TODO Auto-generated method stub
		System.out.println("ĥ������ �簢�簢");
	}

}
