package test2Sol;

public class ProgramingTeacher extends Teacher {

	@Override
	public void Teach() {
		// TODO Auto-generated method stub
		System.out.println("��ǻ�ͷ� Ÿ��Ÿ��");
	}

}
