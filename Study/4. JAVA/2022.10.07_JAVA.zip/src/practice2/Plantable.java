package practice2;

public interface Plantable {
	public void Grow();
	public void Photosynthesis();
}
