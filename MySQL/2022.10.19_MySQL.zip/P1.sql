use jspdb;

create table memberDTO
(
	name varchar(100) not null,
    id varchar(100) primary key,
    pw varchar(100) ,
    gender varchar(100)
);