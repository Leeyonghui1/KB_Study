package com.lecspring.myspring;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import org.springframework.web.servlet.ModelAndView;

import member.MemberDTO;
import member.MemberServiceImpl;

@Controller
public class MemberController {
	@Autowired
	MemberServiceImpl service;
	
	// ȸ������ ȭ��
	@RequestMapping(value = "/member", method = RequestMethod.GET)
	public ModelAndView join() {
		ModelAndView mav = new ModelAndView();
		mav.setViewName("/member/join");
		return mav;
	}
	
	// �Ƿ��� ��� ȭ��
	@RequestMapping(value = "/list.staff", method = RequestMethod.GET)
	public ModelAndView list_staff() {
		ModelAndView mav = new ModelAndView();
		List<MemberDTO> list_staff = service.member_list();
		mav.addObject("list", list_staff);
		mav.setViewName("/member/list");
		return mav;
	}
	
}
