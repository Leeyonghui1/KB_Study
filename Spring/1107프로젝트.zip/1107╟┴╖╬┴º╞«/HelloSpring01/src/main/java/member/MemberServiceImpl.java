package member;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MemberServiceImpl implements MemberService{
	@Autowired
	MemberDAO dao;

	// �Ƿ��� ��� ��ȸ
	@Override
	public List<MemberDTO> member_list() {
		return dao.member_list();
	}
	
}
