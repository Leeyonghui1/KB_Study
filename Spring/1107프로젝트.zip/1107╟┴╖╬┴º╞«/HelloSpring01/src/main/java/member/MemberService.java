package member;

import java.util.List;

public interface MemberService {

	List<MemberDTO> member_list();

}
