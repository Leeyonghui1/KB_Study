package member;

public class MemberDTO {
	
}
