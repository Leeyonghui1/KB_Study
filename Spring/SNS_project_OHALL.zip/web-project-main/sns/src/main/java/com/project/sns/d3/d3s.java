package com.project.sns.d3;

import java.util.List;
import java.util.Map;

public interface d3s {
	List<Map<String, Object>> segu_select(Map<String, Object> map);
	List<Map<String, Object>> susunggu_select(Map<String, Object> map);
}