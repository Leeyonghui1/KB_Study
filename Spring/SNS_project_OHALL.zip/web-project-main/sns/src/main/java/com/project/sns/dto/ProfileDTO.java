package com.project.sns.dto;

public class ProfileDTO {
	private String profile_user_id;
	private String profile_file_name;
	public String getProfile_user_id() {
		return profile_user_id;
	}
	public void setProfile_user_id(String profile_user_id) {
		this.profile_user_id = profile_user_id;
	}
	public String getProfile_file_name() {
		return profile_file_name;
	}
	public void setProfile_file_name(String profile_file_name) {
		this.profile_file_name = profile_file_name;
	}
	
	
}
