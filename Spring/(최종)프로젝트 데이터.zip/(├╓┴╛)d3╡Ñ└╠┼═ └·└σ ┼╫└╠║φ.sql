create table covid(
month		varchar(30),
confCase	varchar(30),
death		varchar(30)
);

INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('9월 1주 여성','312832','263');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('9월 1주 남성','266948','268');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('9월 2주 여성','236294','173');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('9월 2주 남성','198791','176');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('9월 3주 여성','201119','184');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('9월 3주 남성','170929','185');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('9월 4주 여성','216597','175');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('9월 4주 남성','198818','168');

INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 1주 여성','226852','337');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 1주 남성','191036','305');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 2주 여성','81642','81');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 2주 남성','66367','108');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 3주 여성','84199','76');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 3주 남성','67536','77');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 4주 여성','100585','74');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 4주 남성','79546','75');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 5주 여성','138056','80');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('10월 5주 남성','107617','96');

INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('11월 1주 여성','168195','116');
INSERT INTO covid (`month`,`confCase`,`death`) VALUES ('11월 1주 남성','131406','98');