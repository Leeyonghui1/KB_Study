package com.myspring.mypro;

import java.util.Map;

public interface HospitalService {

	String join(Map<String, Object> map);

	int idCheck(String memberId);

}
